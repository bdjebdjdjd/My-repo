package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "capture_logs")
data class CaptureLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val captureType: String, // IMAGE, VIDEO
    val filePath: String,
    val fileUri: String,
    val presetTitle: String,
    val resolution: String,
    val effectApplied: String,
    val callerPackage: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
