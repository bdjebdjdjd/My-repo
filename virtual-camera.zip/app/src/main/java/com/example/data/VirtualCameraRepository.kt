package com.example.data

import kotlinx.coroutines.flow.Flow

class VirtualCameraRepository(
    private val presetDao: PresetDao,
    private val captureLogDao: CaptureLogDao
) {
    val allPresets: Flow<List<PresetEntity>> = presetDao.getAllPresets()
    val allCaptureLogs: Flow<List<CaptureLogEntity>> = captureLogDao.getAllCaptureLogs()

    suspend fun getPresetById(id: Long): PresetEntity? = presetDao.getPresetById(id)

    suspend fun getDefaultPreset(): PresetEntity? = presetDao.getDefaultPreset()

    suspend fun savePreset(preset: PresetEntity): Long {
        return if (preset.id == 0L) {
            presetDao.insertPreset(preset)
        } else {
            presetDao.updatePreset(preset)
            preset.id
        }
    }

    suspend fun setDefaultPreset(id: Long) {
        presetDao.clearDefaultFlags()
        presetDao.setDefaultPreset(id)
    }

    suspend fun deletePreset(preset: PresetEntity) {
        presetDao.deletePreset(preset)
    }

    suspend fun deletePresetById(id: Long) {
        presetDao.deletePresetById(id)
    }

    suspend fun logCapture(log: CaptureLogEntity): Long {
        return captureLogDao.insertCaptureLog(log)
    }

    suspend fun deleteCaptureLog(log: CaptureLogEntity) {
        captureLogDao.deleteCaptureLog(log)
    }

    suspend fun deleteCaptureLogById(id: Long) {
        captureLogDao.deleteCaptureLogById(id)
    }

    suspend fun clearAllCaptureLogs() {
        captureLogDao.clearAll()
    }
}
