package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CaptureLogDao {
    @Query("SELECT * FROM capture_logs ORDER BY timestamp DESC")
    fun getAllCaptureLogs(): Flow<List<CaptureLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCaptureLog(log: CaptureLogEntity): Long

    @Delete
    suspend fun deleteCaptureLog(log: CaptureLogEntity)

    @Query("DELETE FROM capture_logs WHERE id = :id")
    suspend fun deleteCaptureLogById(id: Long)

    @Query("DELETE FROM capture_logs")
    suspend fun clearAll()
}
