package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [PresetEntity::class, CaptureLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class VirtualCameraDatabase : RoomDatabase() {
    abstract fun presetDao(): PresetDao
    abstract fun captureLogDao(): CaptureLogDao

    companion object {
        @Volatile
        private var INSTANCE: VirtualCameraDatabase? = null

        fun getDatabase(context: Context): VirtualCameraDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VirtualCameraDatabase::class.java,
                    "virtual_camera_db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            val dao = getDatabase(context).presetDao()
                            dao.insertPresets(getDefaultPresets())
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        fun getDefaultPresets(): List<PresetEntity> {
            return listOf(
                PresetEntity(
                    id = 1,
                    title = "SMPTE 1080p Test Bars",
                    feedType = "COLOR_BARS",
                    resolution = "1080p (1920x1080)",
                    fps = 30,
                    effectFilter = "NONE",
                    aspectRatio = "16:9",
                    showTimestampHud = true,
                    isDefault = true
                ),
                PresetEntity(
                    id = 2,
                    title = "Matrix Cyber Digital Rain",
                    feedType = "MATRIX_RAIN",
                    resolution = "1080p (1920x1080)",
                    fps = 60,
                    effectFilter = "CYBERPUNK",
                    aspectRatio = "16:9",
                    showTimestampHud = true,
                    isDefault = false
                ),
                PresetEntity(
                    id = 3,
                    title = "Cyber Clock & HUD Stream",
                    feedType = "CYBER_CLOCK",
                    resolution = "720p (1280x720)",
                    fps = 30,
                    effectFilter = "NONE",
                    aspectRatio = "16:9",
                    showTimestampHud = true,
                    isDefault = false
                ),
                PresetEntity(
                    id = 4,
                    title = "Retro VHS Glitch 1998",
                    feedType = "VHS_GLITCH",
                    resolution = "1080p (1920x1080)",
                    fps = 24,
                    effectFilter = "VINTAGE_1998",
                    aspectRatio = "4:3",
                    showTimestampHud = true,
                    isDefault = false
                ),
                PresetEntity(
                    id = 5,
                    title = "Privacy Face Mask Simulator",
                    feedType = "AVATAR_LOOP",
                    resolution = "1080p (1920x1080)",
                    fps = 30,
                    effectFilter = "PRIVACY_BLUR",
                    aspectRatio = "16:9",
                    showTimestampHud = false,
                    isDefault = false
                ),
                PresetEntity(
                    id = 6,
                    title = "Analog TV Static Noise",
                    feedType = "NOISE_STATIC",
                    resolution = "720p (1280x720)",
                    fps = 30,
                    effectFilter = "NOISE",
                    aspectRatio = "16:9",
                    showTimestampHud = true,
                    isDefault = false
                ),
                PresetEntity(
                    id = 7,
                    title = "Hardware Camera Pass-Through",
                    feedType = "CAMERA_FX",
                    resolution = "1080p (1920x1080)",
                    fps = 30,
                    effectFilter = "CYBERPUNK",
                    aspectRatio = "16:9",
                    showTimestampHud = true,
                    isDefault = false
                )
            )
        }
    }
}
