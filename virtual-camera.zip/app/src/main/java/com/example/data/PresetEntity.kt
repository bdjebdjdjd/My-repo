package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "presets")
data class PresetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val feedType: String, // COLOR_BARS, MATRIX_RAIN, CYBER_CLOCK, VHS_GLITCH, LOCAL_IMAGE, LOCAL_VIDEO, CAMERA_FX, NOISE_STATIC, AVATAR_LOOP
    val mediaUri: String? = null,
    val resolution: String = "1080p (1920x1080)",
    val fps: Int = 30,
    val effectFilter: String = "NONE", // NONE, SEPIA, CYBERPUNK, NIGHT_VISION, VINTAGE_1998, NOISE, PRIVACY_BLUR, CHROMA_GREEN, INVERT
    val aspectRatio: String = "16:9", // 16:9, 4:3, 1:1, 9:16
    val zoom: Float = 1.0f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val rotation: Int = 0, // 0, 90, 180, 270
    val isMirrored: Boolean = false,
    val showTimestampHud: Boolean = true,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
