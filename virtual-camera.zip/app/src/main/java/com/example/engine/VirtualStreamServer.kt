package com.example.engine

import android.graphics.Bitmap
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class VirtualStreamServer(
    private val port: Int = 8080,
    private val frameProvider: () -> Bitmap?
) {
    private val isRunning = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    fun start(): Boolean {
        if (isRunning.get()) return true
        return try {
            serverSocket = ServerSocket(port)
            isRunning.set(true)
            serverJob = scope.launch {
                listen()
            }
            Log.d("VirtualStreamServer", "Server started on port $port")
            true
        } catch (e: Exception) {
            Log.e("VirtualStreamServer", "Failed to start server: ${e.message}")
            isRunning.set(false)
            false
        }
    }

    fun stop() {
        isRunning.set(false)
        serverJob?.cancel()
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            Log.e("VirtualStreamServer", "Error closing socket: ${e.message}")
        }
        serverSocket = null
        Log.d("VirtualStreamServer", "Server stopped")
    }

    fun isServerRunning(): Boolean = isRunning.get()

    private suspend fun listen() {
        while (isRunning.get() && scope.isActive) {
            try {
                val socket = serverSocket?.accept() ?: break
                scope.launch {
                    handleClient(socket)
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    Log.e("VirtualStreamServer", "Accept error: ${e.message}")
                }
                break
            }
        }
    }

    private suspend fun handleClient(socket: Socket) {
        try {
            val input = socket.getInputStream().bufferedReader()
            val requestLine = input.readLine() ?: ""
            val output = socket.getOutputStream()

            when {
                requestLine.contains("GET /snapshot") -> {
                    serveSnapshot(output)
                }
                requestLine.contains("GET /live") || requestLine.contains("GET /video.mjpg") -> {
                    serveMjpegStream(output)
                }
                else -> {
                    serveHtmlDashboard(output)
                }
            }
        } catch (e: Exception) {
            Log.e("VirtualStreamServer", "Client handler error: ${e.message}")
        } finally {
            try {
                socket.close()
            } catch (ignored: Exception) {}
        }
    }

    private fun serveSnapshot(output: OutputStream) {
        val bitmap = frameProvider() ?: return
        val byteStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, byteStream)
        val bytes = byteStream.toByteArray()

        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: image/jpeg\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray())
        output.write(bytes)
        output.flush()
    }

    private suspend fun serveMjpegStream(output: OutputStream) {
        val boundary = "vcam_boundary"
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: multipart/x-mixed-replace; boundary=--$boundary\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: keep-alive\r\n\r\n"
        output.write(header.toByteArray())
        output.flush()

        val byteStream = ByteArrayOutputStream()
        while (isRunning.get() && scope.isActive) {
            try {
                val bitmap = frameProvider()
                if (bitmap != null) {
                    byteStream.reset()
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 80, byteStream)
                    val bytes = byteStream.toByteArray()

                    val frameHeader = "--$boundary\r\n" +
                            "Content-Type: image/jpeg\r\n" +
                            "Content-Length: ${bytes.size}\r\n\r\n"
                    output.write(frameHeader.toByteArray())
                    output.write(bytes)
                    output.write("\r\n".toByteArray())
                    output.flush()
                }
                delay(33) // ~30 FPS
            } catch (e: Exception) {
                break
            }
        }
    }

    private fun serveHtmlDashboard(output: OutputStream) {
        val html = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>Virtual Camera Live Stream</title>
                <style>
                    body { background: #0b0f19; color: #fff; font-family: monospace; text-align: center; margin: 0; padding: 20px; }
                    h1 { color: #00e5ff; font-size: 20px; }
                    .card { background: #161f30; border-radius: 12px; padding: 16px; margin: 12px auto; max-width: 600px; border: 1px solid #28374f; }
                    img { width: 100%; border-radius: 8px; border: 2px solid #00e5ff; }
                    .badge { background: #00e5ff; color: #000; font-weight: bold; padding: 4px 8px; border-radius: 4px; display: inline-block; margin-top: 8px; }
                </style>
            </head>
            <body>
                <div class="card">
                    <h1>VCAM LIVE FEED (NON-ROOT)</h1>
                    <img src="/live" alt="Virtual Camera Stream" />
                    <div><span class="badge">ON-DEVICE STREAM • NO PC</span></div>
                    <p>Endpoint: <code>http://localhost:$port/live</code></p>
                </div>
            </body>
            </html>
        """.trimIndent()

        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${html.toByteArray().size}\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray())
        output.write(html.toByteArray())
        output.flush()
    }
}
