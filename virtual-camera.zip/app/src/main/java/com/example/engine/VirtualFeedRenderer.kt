package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

object VirtualFeedRenderer {

    private val matrixDrops = IntArray(40) { Random.nextInt(-20, 0) }
    private val matrixChars = "0123456789ABCDEFｦｱｳｴｵｶｷｹｺｻｼｽｾｿﾀﾂﾃﾅﾆﾇﾈﾊﾋﾎﾏﾐﾑﾒﾓﾔﾕﾗﾘﾜ".toCharArray()

    fun renderProceduralFrame(
        feedType: String,
        width: Int,
        height: Int,
        frameCount: Long,
        baseImage: Bitmap? = null,
        presetTitle: String = "Virtual Camera",
        effectFilter: String = "NONE",
        zoom: Float = 1.0f,
        panX: Float = 0f,
        panY: Float = 0f,
        rotation: Int = 0,
        isMirrored: Boolean = false,
        showTimestampHud: Boolean = true
    ): Bitmap {
        val safeWidth = if (width <= 0) 1280 else width
        val safeHeight = if (height <= 0) 720 else height
        val bitmap = Bitmap.createBitmap(safeWidth, safeHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        when (feedType) {
            "COLOR_BARS" -> drawSmpteBars(canvas, safeWidth, safeHeight, frameCount)
            "MATRIX_RAIN" -> drawMatrixRain(canvas, safeWidth, safeHeight, frameCount)
            "CYBER_CLOCK" -> drawCyberClock(canvas, safeWidth, safeHeight, frameCount)
            "VHS_GLITCH" -> drawVhsGlitch(canvas, safeWidth, safeHeight, frameCount, baseImage)
            "AVATAR_LOOP" -> drawAvatarLoop(canvas, safeWidth, safeHeight, frameCount)
            "NOISE_STATIC" -> drawNoiseStatic(canvas, safeWidth, safeHeight, frameCount)
            "LOCAL_IMAGE" -> {
                if (baseImage != null && !baseImage.isRecycled) {
                    drawScaledBitmap(canvas, baseImage, safeWidth, safeHeight, zoom, panX, panY, rotation, isMirrored)
                } else {
                    drawSmpteBars(canvas, safeWidth, safeHeight, frameCount)
                }
            }
            "CAMERA_FX" -> {
                if (baseImage != null && !baseImage.isRecycled) {
                    drawScaledBitmap(canvas, baseImage, safeWidth, safeHeight, zoom, panX, panY, rotation, isMirrored)
                } else {
                    drawCyberClock(canvas, safeWidth, safeHeight, frameCount)
                }
            }
            else -> drawSmpteBars(canvas, safeWidth, safeHeight, frameCount)
        }

        // Apply visual filter
        if (effectFilter != "NONE") {
            applyEffectToBitmap(canvas, safeWidth, safeHeight, effectFilter, frameCount)
        }

        // Overlay HUD
        if (showTimestampHud) {
            drawHudOverlay(canvas, safeWidth, safeHeight, frameCount, presetTitle, effectFilter)
        }

        return bitmap
    }

    private fun drawSmpteBars(canvas: Canvas, w: Int, h: Int, frameCount: Long) {
        val colors = intArrayOf(
            Color.LTGRAY, Color.YELLOW, Color.CYAN, Color.GREEN,
            Color.MAGENTA, Color.RED, Color.BLUE
        )
        val barWidth = w.toFloat() / colors.size
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Top 66% standard color bars
        val topH = h * 0.67f
        for (i in colors.indices) {
            paint.color = colors[i]
            canvas.drawRect(i * barWidth, 0f, (i + 1) * barWidth, topH, paint)
        }

        // Middle 8% cast bars (Cyan, Dark Blue, Magenta, Black, White)
        val midH = h * 0.75f
        val midColors = intArrayOf(Color.BLUE, Color.BLACK, Color.MAGENTA, Color.BLACK, Color.CYAN, Color.BLACK, Color.LTGRAY)
        for (i in midColors.indices) {
            paint.color = midColors[i]
            canvas.drawRect(i * barWidth, topH, (i + 1) * barWidth, midH, paint)
        }

        // Bottom 25% I, White, Q, Black, Pluge
        val botColors = intArrayOf(
            Color.rgb(0, 33, 77), Color.WHITE, Color.rgb(50, 0, 100),
            Color.BLACK, Color.rgb(20, 20, 20), Color.BLACK, Color.rgb(30, 30, 30)
        )
        for (i in botColors.indices) {
            paint.color = botColors[i]
            canvas.drawRect(i * barWidth, midH, (i + 1) * barWidth, h.toFloat(), paint)
        }

        // Moving test tone indicator
        val scanX = (frameCount * 6 % w).toFloat()
        paint.color = Color.argb(180, 255, 0, 50)
        canvas.drawRect(scanX, 0f, scanX + 6f, h.toFloat(), paint)
    }

    private fun drawMatrixRain(canvas: Canvas, w: Int, h: Int, frameCount: Long) {
        canvas.drawColor(Color.rgb(5, 10, 5))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = (h / 25).toFloat().coerceAtLeast(18f)
            typeface = Typeface.MONOSPACE
        }

        val cols = 30
        val colWidth = w.toFloat() / cols

        for (i in 0 until cols) {
            val dropY = ((frameCount * 3 + i * 17) % (h + 300)) - 100
            for (j in 0..15) {
                val yPos = dropY - j * (paint.textSize * 1.1f)
                if (yPos in 0f..h.toFloat()) {
                    val charIdx = ((frameCount + i + j) % matrixChars.size).toInt()
                    if (j == 0) {
                        paint.color = Color.WHITE
                        paint.setShadowLayer(8f, 0f, 0f, Color.GREEN)
                    } else {
                        val alpha = (255 - j * 16).coerceIn(20, 240)
                        paint.color = Color.argb(alpha, 0, 255, 70)
                        paint.clearShadowLayer()
                    }
                    canvas.drawText(matrixChars[charIdx].toString(), i * colWidth + colWidth / 4, yPos, paint)
                }
            }
        }
    }

    private fun drawCyberClock(canvas: Canvas, w: Int, h: Int, frameCount: Long) {
        // Dark futuristic gradient background
        canvas.drawColor(Color.rgb(10, 15, 28))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Grid lines
        paint.color = Color.argb(40, 0, 220, 255)
        paint.strokeWidth = 1.5f
        val step = (w / 16).toFloat()
        var x = 0f
        while (x < w) {
            canvas.drawLine(x, 0f, x, h.toFloat(), paint)
            x += step
        }
        var y = 0f
        while (y < h) {
            canvas.drawLine(0f, y, w.toFloat(), y, paint)
            y += step
        }

        // Center circular futuristic HUD
        val cx = w / 2f
        val cy = h / 2f
        val radius = (h * 0.32f).coerceAtLeast(80f)

        paint.style = Paint.Style.STROKE
        paint.color = Color.argb(120, 0, 200, 255)
        paint.strokeWidth = 3f
        canvas.drawCircle(cx, cy, radius, paint)

        paint.color = Color.argb(200, 255, 0, 128)
        paint.strokeWidth = 5f
        val angle = (frameCount * 4 % 360).toFloat()
        canvas.drawArc(cx - radius + 15, cy - radius + 15, cx + radius - 15, cy + radius - 15, angle, 90f, false, paint)

        // Digital Clock Text
        val timeFormat = SimpleDateFormat("HH:mm:ss.SS", Locale.US)
        val timeStr = timeFormat.format(Date())

        paint.style = Paint.Style.FILL
        paint.typeface = Typeface.MONOSPACE
        paint.color = Color.CYAN
        paint.textSize = (h * 0.11f).coerceAtLeast(28f)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(timeStr, cx, cy + paint.textSize / 3, paint)

        paint.color = Color.WHITE
        paint.textSize = (h * 0.045f).coerceAtLeast(14f)
        canvas.drawText("VIRTUAL CAMERA ENGINE • 1080P", cx, cy - radius - 20, paint)
        canvas.drawText("NON-ROOT INJECTION ACTIVE", cx, cy + radius + 40, paint)
    }

    private fun drawVhsGlitch(canvas: Canvas, w: Int, h: Int, frameCount: Long, baseImage: Bitmap?) {
        if (baseImage != null && !baseImage.isRecycled) {
            drawScaledBitmap(canvas, baseImage, w, h, 1.0f, 0f, 0f, 0, false)
        } else {
            drawCyberClock(canvas, w, h, frameCount)
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        // Horizontal scanlines
        paint.color = Color.argb(35, 0, 0, 0)
        paint.strokeWidth = 2f
        var y = 0f
        while (y < h) {
            canvas.drawLine(0f, y, w.toFloat(), y, paint)
            y += 4f
        }

        // Random tracking glitch bar
        if (frameCount % 40 < 10) {
            val glitchY = Random.nextInt(0, h - 50).toFloat()
            val glitchH = Random.nextInt(20, 80).toFloat()
            paint.color = Color.argb(100, 255, 255, 255)
            canvas.drawRect(0f, glitchY, w.toFloat(), glitchY + glitchH, paint)
        }

        // VHS Overlay Text
        paint.color = Color.YELLOW
        paint.textSize = (h * 0.06f).coerceAtLeast(20f)
        paint.typeface = Typeface.MONOSPACE
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("PLAY ▶ 00:${String.format(Locale.US, "%02d", (frameCount / 30) % 60)}:00", 40f, h * 0.15f, paint)
        canvas.drawText("SP  CH 03", 40f, h * 0.23f, paint)
    }

    private fun drawAvatarLoop(canvas: Canvas, w: Int, h: Int, frameCount: Long) {
        canvas.drawColor(Color.rgb(18, 24, 38))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val cx = w / 2f
        val cy = h / 2f
        val headRadius = (h * 0.22f).coerceAtLeast(50f)

        // Pulsing glow
        val pulse = kotlin.math.sin(frameCount * 0.1).toFloat() * 10f
        paint.color = Color.argb(150, 40, 120, 255)
        canvas.drawCircle(cx, cy - 30, headRadius + 15 + pulse, paint)

        // Head silhouette
        paint.color = Color.rgb(220, 230, 245)
        canvas.drawCircle(cx, cy - 30, headRadius, paint)

        // Shoulders
        paint.color = Color.rgb(200, 215, 235)
        canvas.drawOval(cx - headRadius * 1.8f, cy + headRadius * 0.6f, cx + headRadius * 1.8f, cy + headRadius * 3f, paint)

        // Animated eyes / glasses
        val blink = (frameCount % 90) < 5
        paint.color = Color.rgb(20, 30, 50)
        if (blink) {
            paint.strokeWidth = 4f
            canvas.drawLine(cx - 35, cy - 40, cx - 15, cy - 40, paint)
            canvas.drawLine(cx + 15, cy - 40, cx + 35, cy - 40, paint)
        } else {
            canvas.drawCircle(cx - 25, cy - 40, 10f, paint)
            canvas.drawCircle(cx + 25, cy - 40, 10f, paint)
        }

        // Subtitle
        paint.color = Color.CYAN
        paint.textSize = 28f
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("VIRTUAL AVATAR • ACTIVE CAM FEED", cx, h * 0.88f, paint)
    }

    private fun drawNoiseStatic(canvas: Canvas, w: Int, h: Int, frameCount: Long) {
        val paint = Paint()
        val numDots = 800
        canvas.drawColor(Color.BLACK)
        for (i in 0 until numDots) {
            val rx = Random.nextInt(0, w).toFloat()
            val ry = Random.nextInt(0, h).toFloat()
            val rw = Random.nextInt(4, 25).toFloat()
            val rh = Random.nextInt(2, 8).toFloat()
            val gray = Random.nextInt(50, 255)
            paint.color = Color.rgb(gray, gray, gray)
            canvas.drawRect(rx, ry, rx + rw, ry + rh, paint)
        }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 36f
            typeface = Typeface.MONOSPACE
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("NO SIGNAL / NOISE GENERATOR", w / 2f, h / 2f, textPaint)
    }

    private fun drawScaledBitmap(
        canvas: Canvas,
        src: Bitmap,
        w: Int,
        h: Int,
        zoom: Float,
        panX: Float,
        panY: Float,
        rotation: Int,
        isMirrored: Boolean
    ) {
        val matrix = Matrix()
        val srcW = src.width.toFloat()
        val srcH = src.height.toFloat()

        val scale = kotlin.math.max(w / srcW, h / srcH) * zoom
        val dx = (w - srcW * scale) / 2f + panX
        val dy = (h - srcH * scale) / 2f + panY

        matrix.postScale(scale, scale)
        matrix.postTranslate(dx, dy)

        if (isMirrored) {
            matrix.postScale(-1f, 1f, w / 2f, h / 2f)
        }
        if (rotation != 0) {
            matrix.postRotate(rotation.toFloat(), w / 2f, h / 2f)
        }

        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        canvas.drawBitmap(src, matrix, paint)
    }

    private fun applyEffectToBitmap(
        canvas: Canvas,
        w: Int,
        h: Int,
        effect: String,
        frameCount: Long
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        when (effect) {
            "SEPIA" -> {
                val cm = ColorMatrix().apply {
                    set(floatArrayOf(
                        0.393f, 0.769f, 0.189f, 0f, 0f,
                        0.349f, 0.686f, 0.168f, 0f, 0f,
                        0.272f, 0.534f, 0.131f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f
                    ))
                }
                paint.colorFilter = ColorMatrixColorFilter(cm)
                paint.color = Color.argb(120, 200, 160, 100)
                canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
            }
            "CYBERPUNK" -> {
                paint.color = Color.argb(45, 0, 255, 255)
                canvas.drawRect(0f, 0f, w.toFloat(), h / 2f, paint)
                paint.color = Color.argb(45, 255, 0, 128)
                canvas.drawRect(0f, h / 2f, w.toFloat(), h.toFloat(), paint)
            }
            "NIGHT_VISION" -> {
                paint.color = Color.argb(110, 0, 240, 60)
                canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
            }
            "INVERT" -> {
                paint.color = Color.argb(60, 255, 255, 255)
                canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
            }
            "PRIVACY_BLUR" -> {
                paint.color = Color.argb(140, 100, 100, 100)
                val cx = w / 2f
                val cy = h / 2f
                canvas.drawCircle(cx, cy, (h * 0.35f), paint)
            }
            "CHROMA_GREEN" -> {
                paint.color = Color.argb(80, 0, 255, 0)
                canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
            }
        }
    }

    private fun drawHudOverlay(
        canvas: Canvas,
        w: Int,
        h: Int,
        frameCount: Long,
        presetTitle: String,
        effectFilter: String
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.MONOSPACE
            textSize = (h * 0.032f).coerceIn(14f, 26f)
        }

        // Top Left: REC dot + Preset name
        val recBlink = (frameCount % 30) < 18
        if (recBlink) {
            paint.color = Color.RED
            canvas.drawCircle(35f, 35f, 10f, paint)
        }
        paint.color = Color.WHITE
        canvas.drawText("LIVE REC", 55f, 42f, paint)

        // Target Preset
        paint.color = Color.CYAN
        canvas.drawText("SRC: $presetTitle", 55f, 75f, paint)

        // Top Right: Target Resolution & FPS
        val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val timeString = timeFormat.format(Date())
        paint.textAlign = Paint.Align.RIGHT
        paint.color = Color.WHITE
        canvas.drawText(timeString, w - 30f, 42f, paint)

        paint.color = Color.rgb(180, 240, 80)
        canvas.drawText("${w}x${h} • 60FPS • FX: $effectFilter", w - 30f, 75f, paint)

        // Bottom Crosshair in center
        val cx = w / 2f
        val cy = h / 2f
        paint.color = Color.argb(90, 255, 255, 255)
        paint.strokeWidth = 1.5f
        canvas.drawLine(cx - 25, cy, cx + 25, cy, paint)
        canvas.drawLine(cx, cy - 25, cx, cy + 25, paint)

        // Bottom Left non-root badge
        paint.textAlign = Paint.Align.LEFT
        paint.color = Color.argb(160, 255, 255, 255)
        canvas.drawText("VCAM-ANDROID-16 • NON-ROOT ACTIVE", 35f, h - 30f, paint)
    }

    fun saveBitmapToUri(context: Context, bitmap: Bitmap, targetUri: Uri): Boolean {
        return try {
            context.contentResolver.openOutputStream(targetUri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun saveBitmapToTempFile(context: Context, bitmap: Bitmap, prefix: String = "vcam_capture"): File {
        val file = File(context.cacheDir, "${prefix}_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
        }
        return file
    }

    fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? {
        return try {
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
