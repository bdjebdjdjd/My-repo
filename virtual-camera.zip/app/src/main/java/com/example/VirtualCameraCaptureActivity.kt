package com.example

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CaptureLogEntity
import com.example.data.VirtualCameraDatabase
import com.example.engine.VirtualFeedRenderer
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class VirtualCameraCaptureActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val outputUri: Uri? = intent.getParcelableExtra(MediaStore.EXTRA_OUTPUT)
        val isVideoRequest = intent.action == MediaStore.ACTION_VIDEO_CAPTURE
        val callerPackage = callingPackage ?: callingActivity?.packageName ?: "Third-Party App"

        setContent {
            MyApplicationTheme(darkTheme = true) {
                VirtualCaptureScreen(
                    outputUri = outputUri,
                    isVideoRequest = isVideoRequest,
                    callerPackage = callerPackage,
                    onCancel = {
                        setResult(Activity.RESULT_CANCELED)
                        finish()
                    },
                    onInject = { bitmap, feedType, filter ->
                        handleCaptureInjection(bitmap, outputUri, isVideoRequest, feedType, filter, callerPackage)
                    }
                )
            }
        }
    }

    private fun handleCaptureInjection(
        bitmap: Bitmap,
        outputUri: Uri?,
        isVideoRequest: Boolean,
        feedType: String,
        filter: String,
        callerPackage: String
    ) {
        val db = VirtualCameraDatabase.getDatabase(this)
        val repo = com.example.data.VirtualCameraRepository(db.presetDao(), db.captureLogDao())

        val resultIntent = Intent()
        var savedUriString = ""
        var savedFilePath = ""

        if (outputUri != null) {
            val success = VirtualFeedRenderer.saveBitmapToUri(this, bitmap, outputUri)
            if (success) {
                savedUriString = outputUri.toString()
                savedFilePath = outputUri.path ?: ""
                resultIntent.data = outputUri
            }
        } else {
            val tempFile = VirtualFeedRenderer.saveBitmapToTempFile(this, bitmap)
            savedFilePath = tempFile.absolutePath
            val contentUri = Uri.fromFile(tempFile)
            savedUriString = contentUri.toString()
            resultIntent.data = contentUri
            resultIntent.putExtra("data", Bitmap.createScaledBitmap(bitmap, 320, 240, true))
        }

        // Log capture in Room DB asynchronously
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            repo.logCapture(
                CaptureLogEntity(
                    captureType = if (isVideoRequest) "VIDEO" else "IMAGE",
                    filePath = savedFilePath,
                    fileUri = savedUriString,
                    presetTitle = "VCAM: $feedType",
                    resolution = "${bitmap.width}x${bitmap.height}",
                    effectApplied = filter,
                    callerPackage = callerPackage
                )
            )
        }

        Toast.makeText(this, "Virtual Frame Injected to $callerPackage!", Toast.LENGTH_SHORT).show()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirtualCaptureScreen(
    outputUri: Uri?,
    isVideoRequest: Boolean,
    callerPackage: String,
    onCancel: () -> Unit,
    onInject: (Bitmap, String, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedFeed by remember { mutableStateOf("COLOR_BARS") }
    var selectedFilter by remember { mutableStateOf("NONE") }
    var customImageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var zoom by remember { mutableFloatStateOf(1.0f) }
    var rotation by remember { mutableIntStateOf(0) }
    var isMirrored by remember { mutableStateOf(false) }
    var showHud by remember { mutableStateOf(true) }

    var currentPreviewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var frameCount by remember { mutableLongStateOf(0L) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val bmp = VirtualFeedRenderer.loadBitmapFromUri(context, uri)
            if (bmp != null) {
                customImageBitmap = bmp
                selectedFeed = "LOCAL_IMAGE"
            }
        }
    }

    // High performance frame loop
    LaunchedEffect(selectedFeed, selectedFilter, customImageBitmap, zoom, rotation, isMirrored, showHud) {
        while (isActive) {
            frameCount++
            val bmp = VirtualFeedRenderer.renderProceduralFrame(
                feedType = selectedFeed,
                width = 800,
                height = 450,
                frameCount = frameCount,
                baseImage = customImageBitmap,
                presetTitle = selectedFeed,
                effectFilter = selectedFilter,
                zoom = zoom,
                rotation = rotation,
                isMirrored = isMirrored,
                showTimestampHud = showHud
            )
            currentPreviewBitmap = bmp
            delay(33) // ~30 FPS
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Virtual Camera Provider", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF00E5FF))
                        Text("Target: $callerPackage", style = MaterialTheme.typography.bodySmall, color = Color(0xFF90CAF9))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0B0F19)
                )
            )
        },
        containerColor = Color(0xFF070A12)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Viewport Frame
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .border(2.dp, Color(0xFF00E5FF), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                shape = RoundedCornerShape(12.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    if (currentPreviewBitmap != null) {
                        Image(
                            bitmap = currentPreviewBitmap!!.asImageBitmap(),
                            contentDescription = "Virtual Camera Feed",
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Intent badge
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp),
                        color = Color(0xAA000000),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (isVideoRequest) "● VIDEO INTENT" else "◉ PHOTO INTENT",
                            color = if (isVideoRequest) Color(0xFFFF5252) else Color(0xFF00E5FF),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Action Button: Inject Virtual Frame
            Button(
                onClick = {
                    currentPreviewBitmap?.let { bmp ->
                        // Render at full 1080p for actual capture injection
                        val highResBmp = VirtualFeedRenderer.renderProceduralFrame(
                            feedType = selectedFeed,
                            width = 1920,
                            height = 1080,
                            frameCount = frameCount,
                            baseImage = customImageBitmap,
                            presetTitle = selectedFeed,
                            effectFilter = selectedFilter,
                            zoom = zoom,
                            rotation = rotation,
                            isMirrored = isMirrored,
                            showTimestampHud = showHud
                        )
                        onInject(highResBmp, selectedFeed, selectedFilter)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(
                    if (isVideoRequest) Icons.Default.Videocam else Icons.Default.CameraAlt,
                    contentDescription = null,
                    tint = Color.Black
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isVideoRequest) "INJECT VIRTUAL VIDEO" else "INJECT VIRTUAL PHOTO",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Feed Selection Row
            Text(
                "SELECT VIRTUAL FEED",
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFF90CAF9),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            val feeds = listOf(
                "COLOR_BARS" to "SMPTE Bars",
                "MATRIX_RAIN" to "Matrix Rain",
                "CYBER_CLOCK" to "Cyber Clock",
                "VHS_GLITCH" to "VHS 1998",
                "AVATAR_LOOP" to "Avatar Face",
                "NOISE_STATIC" to "TV Static",
                "LOCAL_IMAGE" to "Custom Media"
            )

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(feeds) { (feedKey, feedLabel) ->
                    FilterChip(
                        selected = selectedFeed == feedKey,
                        onClick = {
                            if (feedKey == "LOCAL_IMAGE") {
                                imagePickerLauncher.launch("image/*")
                            } else {
                                selectedFeed = feedKey
                            }
                        },
                        label = { Text(feedLabel) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF00E5FF),
                            selectedLabelColor = Color.Black,
                            containerColor = Color(0xFF161F30),
                            labelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Real-time Effects Filter Row
            Text(
                "APPLY REAL-TIME FX FILTER",
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFF90CAF9),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            val filters = listOf(
                "NONE" to "Normal",
                "CYBERPUNK" to "Cyberpunk",
                "SEPIA" to "Sepia Film",
                "NIGHT_VISION" to "Night Vision",
                "VINTAGE_1998" to "Vintage",
                "PRIVACY_BLUR" to "Face Mask",
                "CHROMA_GREEN" to "Green Screen",
                "INVERT" to "Invert"
            )

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filters) { (filterKey, filterLabel) ->
                    FilterChip(
                        selected = selectedFilter == filterKey,
                        onClick = { selectedFilter = filterKey },
                        label = { Text(filterLabel) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFFF4081),
                            selectedLabelColor = Color.White,
                            containerColor = Color(0xFF161F30),
                            labelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Geometry Controls: Zoom, Rotate, Mirror, HUD
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101726)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Zoom (${String.format("%.1f", zoom)}x)", color = Color.White, fontSize = 13.sp)
                        Row {
                            IconButton(onClick = { rotation = (rotation + 90) % 360 }) {
                                Icon(Icons.Default.RotateRight, contentDescription = "Rotate", tint = Color(0xFF00E5FF))
                            }
                            IconButton(onClick = { isMirrored = !isMirrored }) {
                                Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Mirror", tint = if (isMirrored) Color(0xFF00E5FF) else Color.White)
                            }
                            IconButton(onClick = { showHud = !showHud }) {
                                Icon(Icons.Default.Tune, contentDescription = "HUD", tint = if (showHud) Color(0xFF00E5FF) else Color.Gray)
                            }
                        }
                    }

                    Slider(
                        value = zoom,
                        onValueChange = { zoom = it },
                        valueRange = 0.5f..3.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF),
                            inactiveTrackColor = Color(0xFF20304D)
                        )
                    )
                }
            }
        }
    }
}
