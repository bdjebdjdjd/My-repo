package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.engine.VirtualFeedRenderer
import com.example.engine.VirtualStreamServer

class VirtualStreamServerService : Service() {

    private var streamServer: VirtualStreamServer? = null
    private var frameCount: Long = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopServer()
            stopSelf()
            return START_NOT_STICKY
        }

        val feedType = intent?.getStringExtra(EXTRA_FEED_TYPE) ?: "COLOR_BARS"
        val filter = intent?.getStringExtra(EXTRA_FILTER) ?: "NONE"
        val presetTitle = intent?.getStringExtra(EXTRA_PRESET_TITLE) ?: "Virtual Camera"

        startForeground(NOTIFICATION_ID, createNotification())
        startServer(feedType, filter, presetTitle)

        return START_STICKY
    }

    private fun startServer(feedType: String, filter: String, presetTitle: String) {
        streamServer?.stop()
        streamServer = VirtualStreamServer(port = 8080) {
            frameCount++
            VirtualFeedRenderer.renderProceduralFrame(
                feedType = feedType,
                width = 640,
                height = 360,
                frameCount = frameCount,
                presetTitle = presetTitle,
                effectFilter = filter,
                showTimestampHud = true
            )
        }
        streamServer?.start()
    }

    private fun stopServer() {
        streamServer?.stop()
        streamServer = null
    }

    override fun onDestroy() {
        stopServer()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Virtual Camera Server",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows status of virtual camera local stream server"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, VirtualStreamServerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Virtual Camera Server Active")
            .setContentText("Broadcasting on http://localhost:8080/live")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Server", stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "vcam_stream_channel"
        const val NOTIFICATION_ID = 9981
        const val ACTION_STOP = "com.example.vcam.STOP_SERVER"
        const val EXTRA_FEED_TYPE = "extra_feed_type"
        const val EXTRA_FILTER = "extra_filter"
        const val EXTRA_PRESET_TITLE = "extra_preset_title"

        fun startService(context: Context, feedType: String = "COLOR_BARS", filter: String = "NONE", presetTitle: String = "Virtual Camera") {
            val intent = Intent(context, VirtualStreamServerService::class.java).apply {
                putExtra(EXTRA_FEED_TYPE, feedType)
                putExtra(EXTRA_FILTER, filter)
                putExtra(EXTRA_PRESET_TITLE, presetTitle)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, VirtualStreamServerService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
