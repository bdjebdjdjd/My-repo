package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.engine.VirtualFeedRenderer

class VirtualCameraOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var frameCount: Long = 0
    private var currentFeedType = "COLOR_BARS"
    private var currentFilter = "NONE"

    private val frameRunnable = object : Runnable {
        override fun run() {
            frameCount++
            overlayView?.findViewById<ImageView>(R.id.overlay_preview_image)?.let { iv ->
                val bmp = VirtualFeedRenderer.renderProceduralFrame(
                    feedType = currentFeedType,
                    width = 320,
                    height = 180,
                    frameCount = frameCount,
                    presetTitle = "Floating Lens",
                    effectFilter = currentFilter,
                    showTimestampHud = true
                )
                iv.setImageBitmap(bmp)
            }
            handler.postDelayed(this, 66) // ~15 FPS in overlay for battery saving
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE_OVERLAY) {
            removeOverlay()
            stopSelf()
            return START_NOT_STICKY
        }

        currentFeedType = intent?.getStringExtra(EXTRA_FEED_TYPE) ?: "COLOR_BARS"
        currentFilter = intent?.getStringExtra(EXTRA_FILTER) ?: "NONE"

        startForeground(NOTIFICATION_ID, createNotification())
        showOverlayWindow()

        return START_STICKY
    }

    private fun showOverlayWindow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission required for Floating Lens", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        if (overlayView != null) return

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        overlayView = inflater.inflate(R.layout.overlay_camera_hud, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 150
        }

        val titleView = overlayView?.findViewById<TextView>(R.id.overlay_title)
        titleView?.text = "VCAM: $currentFeedType"

        // Drag to move
        val header = overlayView?.findViewById<View>(R.id.overlay_header)
        header?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager?.updateViewLayout(overlayView, params)
                        return true
                    }
                }
                return false
            }
        })

        // Close Button
        overlayView?.findViewById<ImageButton>(R.id.overlay_btn_close)?.setOnClickListener {
            removeOverlay()
            stopSelf()
        }

        // Cycle Feed Button
        overlayView?.findViewById<ImageButton>(R.id.overlay_btn_switch)?.setOnClickListener {
            val feeds = listOf("COLOR_BARS", "MATRIX_RAIN", "CYBER_CLOCK", "VHS_GLITCH", "AVATAR_LOOP", "NOISE_STATIC")
            val nextIdx = (feeds.indexOf(currentFeedType) + 1) % feeds.size
            currentFeedType = feeds[nextIdx]
            titleView?.text = "VCAM: $currentFeedType"
            Toast.makeText(this, "Virtual Lens: $currentFeedType", Toast.LENGTH_SHORT).show()
        }

        // Cycle Filter Button
        overlayView?.findViewById<ImageButton>(R.id.overlay_btn_filter)?.setOnClickListener {
            val filters = listOf("NONE", "CYBERPUNK", "SEPIA", "NIGHT_VISION", "VINTAGE_1998", "PRIVACY_BLUR")
            val nextIdx = (filters.indexOf(currentFilter) + 1) % filters.size
            currentFilter = filters[nextIdx]
            Toast.makeText(this, "FX Filter: $currentFilter", Toast.LENGTH_SHORT).show()
        }

        windowManager?.addView(overlayView, params)
        handler.post(frameRunnable)
    }

    private fun removeOverlay() {
        handler.removeCallbacks(frameRunnable)
        if (overlayView != null) {
            try {
                windowManager?.removeView(overlayView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            overlayView = null
        }
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Virtual Camera Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val closeIntent = Intent(this, VirtualCameraOverlayService::class.java).apply {
            action = ACTION_CLOSE_OVERLAY
        }
        val closePendingIntent = PendingIntent.getService(
            this, 2, closeIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Floating Virtual Lens Active")
            .setContentText("Overlaying virtual camera feed over target apps")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Close Lens", closePendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "vcam_overlay_channel"
        const val NOTIFICATION_ID = 9982
        const val ACTION_CLOSE_OVERLAY = "com.example.vcam.CLOSE_OVERLAY"
        const val EXTRA_FEED_TYPE = "extra_feed_type"
        const val EXTRA_FILTER = "extra_filter"

        fun startOverlay(context: Context, feedType: String = "COLOR_BARS", filter: String = "NONE") {
            val intent = Intent(context, VirtualCameraOverlayService::class.java).apply {
                putExtra(EXTRA_FEED_TYPE, feedType)
                putExtra(EXTRA_FILTER, filter)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopOverlay(context: Context) {
            val intent = Intent(context, VirtualCameraOverlayService::class.java).apply {
                action = ACTION_CLOSE_OVERLAY
            }
            context.startService(intent)
        }
    }
}
