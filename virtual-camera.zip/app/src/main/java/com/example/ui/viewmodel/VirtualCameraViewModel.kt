package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CaptureLogEntity
import com.example.data.PresetEntity
import com.example.data.VirtualCameraDatabase
import com.example.data.VirtualCameraRepository
import com.example.engine.VirtualFeedRenderer
import com.example.service.VirtualCameraOverlayService
import com.example.service.VirtualStreamServerService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class VirtualCameraViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: VirtualCameraRepository

    val allPresets: StateFlow<List<PresetEntity>>
    val allCaptureLogs: StateFlow<List<CaptureLogEntity>>

    private val _activePreset = MutableStateFlow(
        PresetEntity(
            title = "SMPTE 1080p Test Bars",
            feedType = "COLOR_BARS",
            resolution = "1080p (1920x1080)",
            fps = 30,
            effectFilter = "NONE",
            aspectRatio = "16:9",
            showTimestampHud = true
        )
    )
    val activePreset: StateFlow<PresetEntity> = _activePreset.asStateFlow()

    private val _customMediaBitmap = MutableStateFlow<Bitmap?>(null)
    val customMediaBitmap: StateFlow<Bitmap?> = _customMediaBitmap.asStateFlow()

    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private var frameCount: Long = 0

    init {
        val db = VirtualCameraDatabase.getDatabase(application)
        repository = VirtualCameraRepository(db.presetDao(), db.captureLogDao())

        allPresets = repository.allPresets.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allCaptureLogs = repository.allCaptureLogs.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Start render loop for main screen preview
        viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                frameCount++
                val current = _activePreset.value
                val bmp = VirtualFeedRenderer.renderProceduralFrame(
                    feedType = current.feedType,
                    width = 854,
                    height = 480,
                    frameCount = frameCount,
                    baseImage = _customMediaBitmap.value,
                    presetTitle = current.title,
                    effectFilter = current.effectFilter,
                    zoom = current.zoom,
                    panX = current.panX,
                    panY = current.panY,
                    rotation = current.rotation,
                    isMirrored = current.isMirrored,
                    showTimestampHud = current.showTimestampHud
                )
                _previewBitmap.value = bmp
                val delayTime = (1000L / current.fps.coerceIn(15, 60)).coerceAtLeast(16L)
                delay(delayTime)
            }
        }
    }

    fun selectPreset(preset: PresetEntity) {
        _activePreset.value = preset
        showToastMessage("Switched to preset: ${preset.title}")
    }

    fun setFeedType(feedType: String) {
        _activePreset.value = _activePreset.value.copy(feedType = feedType)
    }

    fun setEffectFilter(filter: String) {
        _activePreset.value = _activePreset.value.copy(effectFilter = filter)
    }

    fun setZoom(zoom: Float) {
        _activePreset.value = _activePreset.value.copy(zoom = zoom)
    }

    fun setRotation(rotation: Int) {
        _activePreset.value = _activePreset.value.copy(rotation = rotation)
    }

    fun toggleMirror() {
        _activePreset.value = _activePreset.value.copy(isMirrored = !_activePreset.value.isMirrored)
    }

    fun toggleHud() {
        _activePreset.value = _activePreset.value.copy(showTimestampHud = !_activePreset.value.showTimestampHud)
    }

    fun setResolution(res: String) {
        _activePreset.value = _activePreset.value.copy(resolution = res)
    }

    fun setFps(fps: Int) {
        _activePreset.value = _activePreset.value.copy(fps = fps)
    }

    fun setCustomMediaUri(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val bmp = VirtualFeedRenderer.loadBitmapFromUri(context, uri)
            if (bmp != null) {
                _customMediaBitmap.value = bmp
                _activePreset.value = _activePreset.value.copy(
                    feedType = "LOCAL_IMAGE",
                    mediaUri = uri.toString()
                )
                showToastMessage("Loaded custom media file")
            } else {
                showToastMessage("Failed to load media file")
            }
        }
    }

    fun saveCurrentAsPreset(title: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val current = _activePreset.value
            val newPreset = current.copy(
                id = 0,
                title = title,
                createdAt = System.currentTimeMillis()
            )
            repository.savePreset(newPreset)
            showToastMessage("Saved preset: $title")
        }
    }

    fun deletePreset(preset: PresetEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deletePreset(preset)
            showToastMessage("Deleted preset: ${preset.title}")
        }
    }

    fun triggerSnapshot(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val current = _activePreset.value
            val bmp = VirtualFeedRenderer.renderProceduralFrame(
                feedType = current.feedType,
                width = 1920,
                height = 1080,
                frameCount = frameCount,
                baseImage = _customMediaBitmap.value,
                presetTitle = current.title,
                effectFilter = current.effectFilter,
                zoom = current.zoom,
                panX = current.panX,
                panY = current.panY,
                rotation = current.rotation,
                isMirrored = current.isMirrored,
                showTimestampHud = current.showTimestampHud
            )

            val file = VirtualFeedRenderer.saveBitmapToTempFile(context, bmp, "studio_snapshot")
            val log = CaptureLogEntity(
                captureType = "IMAGE",
                filePath = file.absolutePath,
                fileUri = Uri.fromFile(file).toString(),
                presetTitle = current.title,
                resolution = "1920x1080",
                effectApplied = current.effectFilter,
                callerPackage = "Studio Dashboard"
            )
            repository.logCapture(log)
            showToastMessage("Saved snapshot to Capture Log!")
        }
    }

    fun toggleStreamServer(context: Context) {
        if (_isServerRunning.value) {
            VirtualStreamServerService.stopService(context)
            _isServerRunning.value = false
            showToastMessage("Stream Server Stopped")
        } else {
            val current = _activePreset.value
            VirtualStreamServerService.startService(
                context,
                feedType = current.feedType,
                filter = current.effectFilter,
                presetTitle = current.title
            )
            _isServerRunning.value = true
            showToastMessage("Stream Server Running at http://localhost:8080/live")
        }
    }

    fun toggleOverlay(context: Context) {
        if (!Settings.canDrawOverlays(context)) {
            showToastMessage("Please grant 'Display over other apps' permission")
            return
        }

        if (_isOverlayActive.value) {
            VirtualCameraOverlayService.stopOverlay(context)
            _isOverlayActive.value = false
            showToastMessage("Floating Lens Closed")
        } else {
            val current = _activePreset.value
            VirtualCameraOverlayService.startOverlay(
                context,
                feedType = current.feedType,
                filter = current.effectFilter
            )
            _isOverlayActive.value = true
            showToastMessage("Floating Lens Opened")
        }
    }

    fun deleteCaptureLog(log: CaptureLogEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteCaptureLog(log)
        }
    }

    fun clearAllLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAllCaptureLogs()
        }
    }

    private fun showToastMessage(msg: String) {
        _statusMessage.value = msg
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
