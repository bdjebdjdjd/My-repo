package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.VirtualCameraViewModel

@Composable
fun StreamServerScreen(viewModel: VirtualCameraViewModel) {
    val context = LocalContext.current
    val isServerRunning by viewModel.isServerRunning.collectAsState()
    val activePreset by viewModel.activePreset.collectAsState()

    fun copyToClipboard(text: String, label: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied $label to clipboard!", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Text(
            "LOCAL STREAM MICRO-SERVER",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00E5FF),
            fontFamily = FontFamily.Monospace
        )
        Text(
            "Broadcasts live MJPEG virtual camera stream over on-device localhost:8080 without PC",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF90CAF9)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Main Server Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (isServerRunning) Color(0xFF132A3D) else Color(0xFF101726)
            ),
            shape = RoundedCornerShape(16.dp),
            border = if (isServerRunning) androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF00E5FF)) else null
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .background(
                                    if (isServerRunning) Color(0xFF00E5FF) else Color.Gray,
                                    CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            if (isServerRunning) "SERVER ONLINE • BROADCASTING" else "SERVER OFFLINE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (isServerRunning) Color(0xFF00E5FF) else Color.Gray,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Surface(
                        color = Color(0xFF070C16),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            "PORT 8080",
                            color = Color(0xFFFF4081),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Active Source: ${activePreset.title} (${activePreset.feedType})",
                    fontSize = 13.sp,
                    color = Color.White
                )
                Text(
                    text = "Resolution: ${activePreset.resolution} • Protocol: HTTP/MJPEG Multi-part",
                    fontSize = 11.sp,
                    color = Color(0xFFB0BEC5),
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.toggleStreamServer(context) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isServerRunning) Color(0xFFFF5252) else Color(0xFF00E5FF)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            if (isServerRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (isServerRunning) "STOP SERVER" else "START SERVER",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (isServerRunning) {
                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://localhost:8080/"))
                                context.startActivity(intent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2E4A)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.OpenInBrowser, contentDescription = null, tint = Color(0xFF00E5FF))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Browser", color = Color(0xFF00E5FF))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Endpoints List Card
        Text(
            "STREAMING ENDPOINTS",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00E5FF),
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(8.dp))

        val endpoints = listOf(
            Triple("Live Video MJPEG Feed", "http://localhost:8080/live", "For Chrome, OBS, VLC, WebRTC & WebCam loops"),
            Triple("Direct Image Snapshot", "http://localhost:8080/snapshot", "Returns direct single JPEG snapshot"),
            Triple("Web Video Dashboard", "http://localhost:8080/", "Embedded HTML5 on-device test monitor")
        )

        endpoints.forEach { (name, url, desc) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101726)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                        Text(url, color = Color(0xFF00E5FF), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text(desc, color = Color(0xFF90CAF9), fontSize = 10.sp)
                    }

                    IconButton(onClick = { copyToClipboard(url, name) }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy URL", tint = Color(0xFF00E5FF), modifier = Modifier.size(20.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // How on-device streaming works card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1322)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF80D8FF), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Zero-PC On-Device Integration", color = Color(0xFF80D8FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "Any browser, app cloner, or background service on this phone can consume this stream directly on loopback `127.0.0.1:8080/live` with zero latency without connecting to any PC or external network.",
                    color = Color(0xFFB0BEC5),
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
