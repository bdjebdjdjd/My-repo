package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDim = Color(0xFF00B0FF)
val ElectricMagenta = Color(0xFFFF4081)
val NeonYellow = Color(0xFFFFD54F)

val DarkBackground = Color(0xFF070B14)
val DarkSurface = Color(0xFF0E1626)
val DarkSurfaceCard = Color(0xFF141F33)
val DarkBorder = Color(0xFF1F2F4D)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF90CAF9)
val TextMuted = Color(0xFF78909C)

