package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.VirtualCameraViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(viewModel: VirtualCameraViewModel) {
    val context = LocalContext.current
    val activePreset by viewModel.activePreset.collectAsState()
    val previewBitmap by viewModel.previewBitmap.collectAsState()
    val isServerRunning by viewModel.isServerRunning.collectAsState()
    val isOverlayActive by viewModel.isOverlayActive.collectAsState()

    var showSaveDialog by remember { mutableStateOf(false) }
    var presetNameInput by remember { mutableStateOf("") }

    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setCustomMediaUri(context, uri)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status Bar Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10192A)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF00E5FF), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "NON-ROOT VCAM ENGINE • ANDROID 16+",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E5FF),
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = activePreset.resolution,
                    fontSize = 11.sp,
                    color = Color(0xFF80D8FF),
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Virtual Camera Studio Viewport Monitor
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .border(2.dp, Brush.horizontalGradient(listOf(Color(0xFF00E5FF), Color(0xFFFF4081))), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (previewBitmap != null) {
                    Image(
                        bitmap = previewBitmap!!.asImageBitmap(),
                        contentDescription = "Virtual Camera Studio Viewport",
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Top Left Overlay Stats
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    color = Color(0xAA0B0F19),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACTIVE FEED: ${activePreset.feedType}",
                            color = Color(0xFF00E5FF),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Top Right FX Overlay
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp),
                    color = Color(0xAA0B0F19),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "FX: ${activePreset.effectFilter}",
                        color = Color(0xFFFF4081),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                // Bottom Center Action Controls Bar over Monitor
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(8.dp),
                    color = Color(0xCC070A12),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { viewModel.toggleMirror() }) {
                            Icon(
                                Icons.Default.FlipCameraAndroid,
                                contentDescription = "Mirror Feed",
                                tint = if (activePreset.isMirrored) Color(0xFF00E5FF) else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        IconButton(onClick = { viewModel.setRotation((activePreset.rotation + 90) % 360) }) {
                            Icon(
                                Icons.Default.RotateRight,
                                contentDescription = "Rotate Feed",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        IconButton(onClick = { viewModel.toggleHud() }) {
                            Icon(
                                Icons.Default.Tune,
                                contentDescription = "Toggle HUD Overlay",
                                tint = if (activePreset.showTimestampHud) Color(0xFF00E5FF) else Color.Gray,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        IconButton(onClick = { mediaPickerLauncher.launch("image/*") }) {
                            Icon(
                                Icons.Default.Folder,
                                contentDescription = "Load Media File",
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        IconButton(onClick = { viewModel.triggerSnapshot(context) }) {
                            Icon(
                                Icons.Default.CameraAlt,
                                contentDescription = "Capture Snapshot",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Launch Hub: Floating Lens & Micro-Stream Server
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Floating Lens Button
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable {
                        if (!Settings.canDrawOverlays(context)) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        } else {
                            viewModel.toggleOverlay(context)
                        }
                    },
                colors = CardDefaults.cardColors(
                    containerColor = if (isOverlayActive) Color(0xFF1E3A5F) else Color(0xFF131D2E)
                ),
                shape = RoundedCornerShape(14.dp),
                border = if (isOverlayActive) androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF00E5FF)) else null
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.PictureInPicture,
                            contentDescription = null,
                            tint = if (isOverlayActive) Color(0xFF00E5FF) else Color.White
                        )
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(if (isOverlayActive) Color(0xFF00E5FF) else Color.Gray, CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        if (isOverlayActive) "FLOATING LENS ON" else "START FLOATING LENS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color.White
                    )
                    Text("Overlays Zoom, Meet, Apps", fontSize = 10.sp, color = Color(0xFF90CAF9))
                }
            }

            // Localhost MJPEG Stream Server Button
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.toggleStreamServer(context) },
                colors = CardDefaults.cardColors(
                    containerColor = if (isServerRunning) Color(0xFF331E40) else Color(0xFF131D2E)
                ),
                shape = RoundedCornerShape(14.dp),
                border = if (isServerRunning) androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFF4081)) else null
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.WifiTethering,
                            contentDescription = null,
                            tint = if (isServerRunning) Color(0xFFFF4081) else Color.White
                        )
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(if (isServerRunning) Color(0xFFFF4081) else Color.Gray, CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        if (isServerRunning) "STREAM SERVER: :8080" else "START STREAM SERVER",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color.White
                    )
                    Text("http://localhost:8080/live", fontSize = 10.sp, color = Color(0xFFFF80AB))
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Virtual Feed Type Selector
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF101726)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    "VIRTUAL FEED GENERATORS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF00E5FF),
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(10.dp))

                val feeds = listOf(
                    "COLOR_BARS" to "SMPTE Color Bars",
                    "MATRIX_RAIN" to "Cyber Matrix Rain",
                    "CYBER_CLOCK" to "Digital HUD Clock",
                    "VHS_GLITCH" to "VHS Tape Glitch",
                    "AVATAR_LOOP" to "Virtual Avatar",
                    "NOISE_STATIC" to "TV Static Noise",
                    "LOCAL_IMAGE" to "Custom Media / Photo",
                    "CAMERA_FX" to "Camera Loop Injector"
                )

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(feeds) { (feedKey, feedTitle) ->
                        FilterChip(
                            selected = activePreset.feedType == feedKey,
                            onClick = {
                                if (feedKey == "LOCAL_IMAGE") {
                                    mediaPickerLauncher.launch("image/*")
                                } else {
                                    viewModel.setFeedType(feedKey)
                                }
                            },
                            label = { Text(feedTitle, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF00E5FF),
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0xFF182336),
                                labelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Real-Time FX Filters
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF101726)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    "REAL-TIME FX FILTERS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFF4081),
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(10.dp))

                val filters = listOf(
                    "NONE" to "Direct / Pass",
                    "CYBERPUNK" to "Neon Cyberpunk",
                    "SEPIA" to "Warm Sepia Film",
                    "NIGHT_VISION" to "Night Vision Green",
                    "VINTAGE_1998" to "Vintage 1998",
                    "PRIVACY_BLUR" to "Privacy Mask Blur",
                    "CHROMA_GREEN" to "Chroma Green",
                    "INVERT" to "Color Inversion"
                )

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filters) { (filterKey, filterTitle) ->
                        FilterChip(
                            selected = activePreset.effectFilter == filterKey,
                            onClick = { viewModel.setEffectFilter(filterKey) },
                            label = { Text(filterTitle, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFFF4081),
                                selectedLabelColor = Color.White,
                                containerColor = Color(0xFF182336),
                                labelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Fine-Tuning & Geometry Controls
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF101726)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Digital Optical Zoom", color = Color.White, fontSize = 13.sp)
                    Text("${String.format("%.1f", activePreset.zoom)}x", color = Color(0xFF00E5FF), fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                }

                Slider(
                    value = activePreset.zoom,
                    onValueChange = { viewModel.setZoom(it) },
                    valueRange = 0.5f..3.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF00E5FF),
                        activeTrackColor = Color(0xFF00E5FF),
                        inactiveTrackColor = Color(0xFF1F2F47)
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            presetNameInput = "Preset ${activePreset.feedType}"
                            showSaveDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2E4A)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save as Preset", color = Color(0xFF00E5FF), fontSize = 12.sp)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = activePreset.fps == 30,
                            onClick = { viewModel.setFps(30) },
                            label = { Text("30 FPS", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF00E5FF),
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0xFF162133),
                                labelColor = Color.White
                            )
                        )
                        FilterChip(
                            selected = activePreset.fps == 60,
                            onClick = { viewModel.setFps(60) },
                            label = { Text("60 FPS", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF00E5FF),
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0xFF162133),
                                labelColor = Color.White
                            )
                        )
                    }
                }
            }
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Virtual Camera Preset", color = Color.White) },
            text = {
                Column {
                    Text("Enter a name for this custom feed and filter preset:", color = Color(0xFFB0BEC5), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = presetNameInput,
                        onValueChange = { presetNameInput = it },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00E5FF),
                            unfocusedBorderColor = Color(0xFF37474F),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (presetNameInput.isNotBlank()) {
                            viewModel.saveCurrentAsPreset(presetNameInput.trim())
                            showSaveDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = Color(0xFF10192A)
        )
    }
}
