package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Camera
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NonRootGuideScreen() {
    val context = LocalContext.current

    fun copyText(text: String, label: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied $label to clipboard!", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Text(
            "ANDROID 16+ NON-ROOT GUIDE",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00E5FF),
            fontFamily = FontFamily.Monospace
        )
        Text(
            "4 proven methods to operate virtual camera on non-rooted Android with ZERO PC requirements",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF90CAF9)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Method 1: System Intent Interception
        GuideExpandableCard(
            title = "1. Camera Intent Interception (Instant)",
            subtitle = "For Apps, KYC Verification, Form Uploads, Chat Apps",
            icon = Icons.Default.CameraAlt,
            iconTint = Color(0xFF00E5FF),
            initiallyExpanded = true
        ) {
            Text(
                "When third-party apps request a camera capture via standard Android `IMAGE_CAPTURE` or `VIDEO_CAPTURE` intents:",
                color = Color(0xFFB0BEC5),
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            BulletPoint("1. Open your target app (e.g. WhatsApp, Discord, Browser upload, document scanner).")
            BulletPoint("2. Tap 'Take Photo' or 'Camera'.")
            BulletPoint("3. In the system app chooser, select 'Virtual Camera'.")
            BulletPoint("4. In the virtual camera preview, choose your preset feed, apply real-time filters (or load a custom photo/media), adjust zoom, and tap 'INJECT VIRTUAL PHOTO'.")
            BulletPoint("5. The virtual frame is immediately delivered to the requesting app!")
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Method 2: Floating Lens HUD Overlay
        GuideExpandableCard(
            title = "2. Floating Picture-in-Picture Lens",
            subtitle = "For Live Video Calls: Zoom, Google Meet, Teams, Telegram",
            icon = Icons.Default.PictureInPicture,
            iconTint = Color(0xFFFF4081)
        ) {
            Text(
                "For live video conference apps running in full-screen mode on non-rooted devices:",
                color = Color(0xFFB0BEC5),
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            BulletPoint("1. In Virtual Camera Studio, tap 'START FLOATING LENS'.")
            BulletPoint("2. Grant the 'Display over other apps' permission if prompted.")
            BulletPoint("3. A draggable HUD lens will float over your screen while you open Zoom, Meet, or Teams.")
            BulletPoint("4. Use the floating controls to switch video feeds, cycle filters (cyberpunk, night vision, privacy mask), and pan/zoom the feed in real time.")
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Method 3: Local MJPEG Micro-Server
        GuideExpandableCard(
            title = "3. Localhost Micro-Server (Zero PC)",
            subtitle = "For Chrome on Android, WebRTC, OBS & Local Loopback",
            icon = Icons.Default.WifiTethering,
            iconTint = Color(0xFF80D8FF)
        ) {
            Text(
                "Broadcast a standard multi-part MJPEG camera stream directly inside the phone's loopback interface:",
                color = Color(0xFFB0BEC5),
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            BulletPoint("1. Navigate to the 'Stream Server' tab in this app.")
            BulletPoint("2. Tap 'START SERVER' (binds to port 8080).")
            BulletPoint("3. Open Chrome or any browser on your Android device and visit:")
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF080D18))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("http://localhost:8080/live", color = Color(0xFF00E5FF), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    IconButton(onClick = { copyText("http://localhost:8080/live", "Stream URL") }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                    }
                }
            }

            BulletPoint("4. Web applications, virtual reality viewers, or local network monitors can directly consume the feed in real time.")
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Method 4: Shizuku & Wireless ADB Direct on Device
        GuideExpandableCard(
            title = "4. Wireless Debugging & Shizuku (No PC)",
            subtitle = "For Advanced Camera Device Emulation & Virtual Hooking",
            icon = Icons.Default.Code,
            iconTint = Color(0xFFFFD54F)
        ) {
            Text(
                "Modern Android (14/15/16+) allows pairing Wireless ADB directly on device without any computer:",
                color = Color(0xFFB0BEC5),
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            BulletPoint("1. Enable Developer Options: Go to Settings -> About Phone -> Tap 'Build Number' 7 times.")
            BulletPoint("2. Go to Developer Options -> Toggle 'Wireless Debugging' ON.")
            BulletPoint("3. Open Shizuku (free on Google Play) -> Tap 'Pairing' using Split Screen or Notification code.")
            BulletPoint("4. Start Shizuku service. You now have ADB privileges directly on your phone without ever touching a PC!")
            BulletPoint("5. Optional Camera HAL query command:")

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF080D18))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("cmd media.camera get-camera-info", color = Color(0xFFFFD54F), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    IconButton(onClick = { copyText("cmd media.camera get-camera-info", "Camera Info Command") }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color(0xFFFFD54F), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun GuideExpandableCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    initiallyExpanded: Boolean = false,
    content: @Composable () -> Unit
) {
    var expanded by remember { mutableStateOf(initiallyExpanded) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101726)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(0xFF19253B), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                        Text(subtitle, color = Color(0xFF90CAF9), fontSize = 10.sp)
                    }
                }

                Icon(
                    if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color.White
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    content()
                }
            }
        }
    }
}

@Composable
fun BulletPoint(text: String) {
    Row(modifier = Modifier.padding(vertical = 3.dp)) {
        Text("•", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 6.dp))
        Text(text, color = Color(0xFFECEFF1), fontSize = 12.sp, lineHeight = 16.sp)
    }
}
